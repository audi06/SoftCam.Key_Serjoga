#!/bin/sh
################################################################
# Title:.......KeyUpdate                                       #
# Author:......audi06_19   2018                                #
# Support:.....www.dreamosat-forum.com                         #
# E-Mail:......admin@dreamosat-forum.com                       #
# Date:........26.11.2018                                      #
# Description:.KeyUpdate                                       #
################################################################

from Plugins.Plugin import PluginDescriptor
from Screens.Console import Console
from Screens.MessageBox import MessageBox
import os
from os import remove, rename, system
import sys

def menu(menuid, **kwargs):
    if menuid == 'mainmenu':
        return [('KeyUpdate',
          main,
          'KeyUpdate',
          1)]
    return []
def runbackup(session, result):
    if result:
	session.open(Console, title='KeyUpdate', cmdlist=["curl -s -Lkb -m 4 -m 6 https://raw.githubusercontent.com/audi06/SoftCam.Key_Serjoga/master/KeyUpdate.sh | /bin/sh"])

def main(session, **kwargs):
    session.openWithCallback(lambda r: runbackup(session, r), MessageBox, 'KeyUpdate \nKeyUpdate Do you want to update?', MessageBox.TYPE_YESNO, timeout=20, default=True)

def Plugins(**kwargs):
    return [PluginDescriptor(name='KeyUpdate', description='KeyUpdate for online Generator', where=PluginDescriptor.WHERE_PLUGINMENU, fnc=main, icon='plugin.png')]
